#include "apilib.h"

void HariMain(void)
{
	api_putstr0("hello, world\n");
	api_end();
}
